// src/core/assets/sfnt.ts
var tag = (b, o) => String.fromCharCode(b[o], b[o + 1], b[o + 2], b[o + 3]);
var u16 = (b, o) => b[o] << 8 | b[o + 1];
var u32 = (b, o) => (b[o] << 24 | b[o + 1] << 16 | b[o + 2] << 8 | b[o + 3]) >>> 0;
async function faceOffsets(read) {
  const h = await read(0, 12);
  if (h.length < 12) return [];
  const t = tag(h, 0);
  if (t === "ttcf") {
    const n = u32(h, 8);
    const o = await read(12, n * 4);
    return Array.from({ length: n }, (_, i) => u32(o, i * 4));
  }
  return t === "OTTO" || t === "true" || u32(h, 0) === 65536 ? [0] : [];
}
async function tables(read, at) {
  const n = u16(await read(at + 4, 2), 0);
  const d = await read(at + 12, n * 16);
  const out = /* @__PURE__ */ new Map();
  for (let i = 0; i < n; i++) out.set(tag(d, i * 16), { tag: tag(d, i * 16), offset: u32(d, i * 16 + 8), length: u32(d, i * 16 + 12) });
  return out;
}
var utf16 = (b) => String.fromCharCode(...Array.from({ length: b.length >> 1 }, (_, i) => u16(b, i * 2)));
var latin1 = (b) => String.fromCharCode(...b);
function names(b) {
  const count = u16(b, 2);
  const strings = u16(b, 4);
  const best = {};
  for (let i = 0; i < count; i++) {
    const r = 6 + i * 12;
    const [platform, encoding, lang, id, len, off] = [0, 2, 4, 6, 8, 10].map((k) => u16(b, r + k));
    const score = platform === 3 && (encoding === 1 || encoding === 10) ? lang === 1033 ? 4 : 3 : platform === 0 ? 2 : platform === 1 && encoding === 0 && lang === 0 ? 1 : 0;
    if (!score || (best[id]?.score ?? 0) >= score) continue;
    const raw = b.subarray(strings + off, strings + off + len);
    best[id] = { score, text: platform === 1 ? latin1(raw) : utf16(raw) };
  }
  return Object.fromEntries(Object.entries(best).map(([k, v]) => [k, v.text.trim()]));
}
var embeddable = (fsType) => !(fsType & 2 && !(fsType & 12) || fsType & 512);
async function readFaces(read) {
  const out = [];
  for (const [index, at] of (await faceOffsets(read)).entries()) {
    const t = await tables(read, at);
    const name = t.get("name");
    if (!name) continue;
    const n = names(await read(name.offset, name.length));
    const os2 = t.get("OS/2");
    const fsType = os2 && os2.length >= 10 ? u16(await read(os2.offset + 8, 2), 0) : 0;
    const outlines = t.has("glyf") && t.has("loca") || t.has("CFF ");
    out.push({
      index,
      family: n[1] ?? "",
      style: n[2] || "Regular",
      postscriptName: n[6] ?? "",
      embeddable: embeddable(fsType),
      usable: outlines && !t.has("sbix") && !t.has("CBDT") && !t.has("fvar")
    });
  }
  return out;
}
function extractFace(bytes, index) {
  if (tag(bytes, 0) !== "ttcf") return bytes;
  if (index >= u32(bytes, 8)) throw new Error(`No face ${index} in the collection`);
  const at = u32(bytes, 12 + index * 4);
  const n = u16(bytes, at + 4);
  const dir = at + 12;
  const pad = (len) => len + 3 & ~3;
  let size = 12 + n * 16;
  for (let i = 0; i < n; i++) size += pad(u32(bytes, dir + i * 16 + 12));
  const out = new Uint8Array(size);
  const view = new DataView(out.buffer);
  out.set(bytes.subarray(at, at + 12), 0);
  let pos = 12 + n * 16;
  for (let i = 0; i < n; i++) {
    const e = dir + i * 16;
    const offset = u32(bytes, e + 8);
    const length = u32(bytes, e + 12);
    out.set(bytes.subarray(e, e + 8), 12 + i * 16);
    view.setUint32(12 + i * 16 + 8, pos);
    view.setUint32(12 + i * 16 + 12, length);
    out.set(bytes.subarray(offset, offset + length), pos);
    pos += pad(length);
  }
  return out;
}

// tiny/backend/main.ts
var SKIP = /^\./;
async function walk(root, rel, out) {
  const dir = rel ? `${root}/${rel}` : root;
  for await (const entry of await tjs.readDir(dir)) {
    if (SKIP.test(entry.name)) continue;
    const path = rel ? `${rel}/${entry.name}` : entry.name;
    if (entry.isDirectory) await walk(root, path, out);
    else out.push(path);
  }
  return out;
}
function resolve(dir, path) {
  if (path.split("/").includes("..")) throw new Error("Invalid path");
  return `${dir}/${path}`;
}
async function ensureParent(file) {
  const parent = file.slice(0, file.lastIndexOf("/"));
  if (parent) await tjs.makeDir(parent, { recursive: true });
}
function toBase64(bytes) {
  let s = "";
  for (let i = 0; i < bytes.length; i += 32768) s += String.fromCharCode(...bytes.subarray(i, i + 32768));
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
var isDir = (path) => tjs.stat(path).then((s) => s.isDirectory, () => false);
var FONT_DIRS = [
  `${tjs.homeDir}/Library/Fonts`,
  "/Library/Fonts",
  "/System/Library/Fonts",
  `${tjs.homeDir}/.local/share/fonts`,
  `${tjs.homeDir}/.fonts`,
  "/usr/local/share/fonts",
  "/usr/share/fonts",
  tjs.env.LOCALAPPDATA && `${tjs.env.LOCALAPPDATA}/Microsoft/Windows/Fonts`,
  // fonts installed for one user
  `${tjs.env.WINDIR ?? "C:/Windows"}/Fonts`
].filter(Boolean);
var FONT_FILE = /\.(ttf|otf|ttc|otc)$/i;
async function fontFiles() {
  const out = [];
  for (const dir of FONT_DIRS) {
    const files = await walk(dir, "", []).catch(() => []);
    out.push(...files.filter((f) => FONT_FILE.test(f)).map((f) => `${dir}/${f}`));
  }
  return out;
}
async function fileFaces(path) {
  const file = await tjs.open(path, "r");
  try {
    const read = async (offset, length) => {
      const buf = new Uint8Array(length);
      return buf.subarray(0, await file.read(buf, offset) ?? 0);
    };
    return await readFaces(read);
  } finally {
    await file.close();
  }
}
var api = {
  isDir: async ({ path }) => isDir(path),
  // Creates the default workspace folder on first launch (chosen by the page).
  makeDir: async ({ path }) => tjs.makeDir(path, { recursive: true }),
  list: async ({ dir }) => (await walk(dir, "", [])).sort(),
  // tjs.readFile always returns bytes (it has no encoding option).
  readText: async ({ dir, path }) => new TextDecoder().decode(await tjs.readFile(resolve(dir, path))),
  readBase64: async ({ dir, path }) => toBase64(await tjs.readFile(resolve(dir, path))),
  writeText: async ({ dir, path, text }) => {
    const file = resolve(dir, path);
    await ensureParent(file);
    await tjs.writeFile(file, text);
  },
  writeBase64: async ({ dir, path, data }) => {
    const file = resolve(dir, path);
    await ensureParent(file);
    await tjs.writeFile(file, fromBase64(data));
  },
  remove: async ({ dir, path }) => tjs.remove(resolve(dir, path)),
  rename: async ({ dir, from, to }) => {
    const target = resolve(dir, to);
    const exists = await tjs.stat(target).then(() => true, () => false);
    if (exists) throw new Error(`File exists: ${to}`);
    await ensureParent(target);
    await tjs.rename(resolve(dir, from), target);
  },
  // Files chosen by the user in a native open dialog.
  readAbsolute: async ({ path }) => toBase64(await tjs.readFile(path)),
  // Target chosen by the user in a native save dialog.
  writeAbsolute: async ({ path, data }) => tjs.writeFile(path, fromBase64(data)),
  // Installed fonts that may be embedded in documents (licence flags allow it, and
  // the outlines are a kind the PDF writer handles). Unreadable files are skipped.
  systemFonts: async () => {
    const out = [];
    for (const path of await fontFiles()) {
      const faces = await fileFaces(path).catch(() => []);
      for (const f of faces) if (f.embeddable && f.usable) out.push({ path, index: f.index, family: f.family, style: f.style });
    }
    return out;
  },
  // One installed face as a standalone font file (taken out of its collection).
  readFontFace: async ({ path, index }) => toBase64(extractFace(await tjs.readFile(path), index))
};
export {
  api
};
